/*
Emma Jerrier
February 3rd 2022
CSC1720
~/csc1720/lab4
About: We created a header, implementation, and main file and defined, implemented and tested the class respectively. I defined multiple vehicles to test different values through. I defined 3 private values in the class and used the methods in the class to access them, modify them, and print them. We also narrated what we were doing throughout and I said what I was inputting and what I expected it to output/correct to.
compile: g++ -c autoTypeImp.cpp g++ autoMain.cpp autoTypeImp.o
run: ./a.out
resource: https://www.cplusplus.com/reference/string/to_string/
*/

#include <iostream>
// included string to be able to concatenate it :) and included the header so the class would be defined
#include <string>
#include "autoType.h"

using namespace std;

/*
setValues - this method sets the values for the vehicle to whatever I decided them as, because it was NOT interactive. I used if elses to make sure all the values were reasonable for the variables
Precondition: the local variables for the odometer, fuel level, and fuel efficiency are passed in and have already been selected. The values will be tested to make sure they're reasonable, and then will be assigned to the private values fro odometer, fuel level, and fuel efficiency
Postcondition: The three values passed in would have been assigned to the private values, or the 'failsafe' values would have been assigned
*/
void autoType::setValues(double od, double fl, double fe)
{
   if(od>=0)
      odometer = od;
   else
      odometer = 0;
 
   if(fl>=0)
      fuelLev = fl;
   else
      fuelLev = 0;

   if(fe>=0)
      fuelEff = fe;
   else
      fuelEff = 0;
}

/*
createDash - this method concatenates the output into one string. I had to use the to_string function to be able to add in the double values without it messing up the string. then the string value is returned to the main program. :)
Precondition: Nothing is passed in, but the method accesses the private values that have already been initialized and will use the to_string function to add them into the string that will be returned
Postcondition: the output string will be returned to main including the private values.
*/
string autoType::createDash()
{
   string output;
   output = "Odometer = " + to_string(odometer) + " miles, Fuel Level = " + to_string(fuelLev) + " gallons, Efficiency = " + to_string(fuelEff) + " miles per gallon.";
   return output;
}

/*
drive - this method 'drives' the car a set amount of miles which is passed in from main and modifies each of the private variables accordingly. So the odometer should increase the number of miles traveled and the fuel level will decrease the amount that they would burn (miles divided by fuel efficiency). 
Precondition: the number of miles is passed in and will be used to calculate the amount of gallons spent and will modify the fuel level and the odometer. 
Postcondition: the private variables will be accessed and the fuel level and odometer will be modified
*/
void autoType::drive(double miles)
{
   double gallons;
   if(fuelEff>0)
      gallons = miles/fuelEff;
   else
      gallons = 0;
     
   if (gallons<fuelLev)
      fuelLev-=gallons;
   else
      fuelLev=0;
   if (fuelEff>0)
      odometer+=miles;  
}

/*
autoType - This method is the first constructor that uses set values when the object is declared and will test the values and either use the set ones or the 'failsafe' values to assign it to the private variables. I also used if else's to ensure that the values were reasonable and not anything that didn't make sense
Precondition: 3 variables are passed in that will be assigned to the private values for each object after being tested to make sure they're not weird
Postcondition: the private variables will be accessed and modified to new values for the objects
*/
autoType::autoType(double od, double fl, double fe)
{
   if(od>=0 && od<300000)
      odometer = od;
   else
      odometer = 100;

   if(fl>=0)
      fuelLev = fl;
   else
      fuelLev = 0;

   if(fe>=10)
      fuelEff = fe;
   else
      fuelEff = 10;
}

/*
autoType (default) - this is the default constructor so it will just set the object to what I decided as the 'default' values for each of the private variables.
Precondition: nothing is passed in but the private variables will be accessed and changed into new values
Postcondition: the private variables will be modified to 100, 0, and 10 respectively 
*/
autoType::autoType()
{
   odometer = 100;
   fuelLev = 0;
   fuelEff = 10;
}
